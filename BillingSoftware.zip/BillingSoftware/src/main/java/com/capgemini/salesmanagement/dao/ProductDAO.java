/**
 * 
 */
package com.capgemini.salesmanagement.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import com.capgemini.salesmanagement.beans.ProductBean;
import com.capgemini.salesmanagement.utility.*;
/**
 * @author VJIT
 *
 */
public class ProductDAO implements IProductDAO{

	public int getProductDetails(int productCode) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		DataConnection d=new DataConnection();
		Connection con=d.connect();
		
		Scanner in=new Scanner(System.in);
		System.out.println("Enter the product code :");
		int code=in.nextInt();
		System.out.println("Enter the quantity :");
		int quant=in.nextInt();
		if(quant<=0) {
			System.out.println("please enter the correct quantity");
		}
		//if(code==get)
		
		return productCode;
	}

	public boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		
		return false;
	}

}
