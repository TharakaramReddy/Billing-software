package com.capgemini.salesmanagement.dao;

import java.sql.SQLException;

import com.capgemini.salesmanagement.beans.ProductBean;

public interface IProductDAO {

	int getProductDetails(int  productCode) throws ClassNotFoundException, SQLException;
	boolean insertSalesDetails(ProductBean product) throws ClassNotFoundException, SQLException;
}
