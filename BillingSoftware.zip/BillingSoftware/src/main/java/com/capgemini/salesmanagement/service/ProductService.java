/**
 * 
 */
package com.capgemini.salesmanagement.service;

import com.capgemini.salesmanagement.beans.ProductBean;

/**
 * @author VJIT
 *
 */
public class ProductService implements IProductService{

	public ProductBean getProductDetails(int productCode) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean insertSalesDetails(ProductBean product) {
		// TODO Auto-generated method stub
		return false;
	}

}
