/**
 * 
 */
package com.capgemini.salesmanagement.beans;

/**
 * @author VJIT
 *
 */
public class ProductBean {
private int product_code,sales_id,quantity,line_total;
private String product_name,product_category,product_description;
double product_price;
/**
 * @return the product_code
 */
public int getProduct_code() {
	return product_code;
}
/**
 * @param product_code the product_code to set
 */
public void setProduct_code(int product_code) {
	this.product_code = product_code;
}
/**
 * @return the sales_id
 */
public int getSales_id() {
	return sales_id;
}
/**
 * @param sales_id the sales_id to set
 */
public void setSales_id(int sales_id) {
	this.sales_id = sales_id;
}
/**
 * @return the quantity
 */
public int getQuantity() {
	return quantity;
}
/**
 * @param quantity the quantity to set
 */
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
/**
 * @return the line_total
 */
public int getLine_total() {
	return line_total;
}
/**
 * @param line_total the line_total to set
 */
public void setLine_total(int line_total) {
	this.line_total = line_total;
}
/**
 * @return the product_name
 */
public String getProduct_name() {
	return product_name;
}
/**
 * @param product_name the product_name to set
 */
public void setProduct_name(String product_name) {
	this.product_name = product_name;
}
/**
 * @return the product_category
 */
public String getProduct_category() {
	return product_category;
}
/**
 * @param product_category the product_category to set
 */
public void setProduct_category(String product_category) {
	this.product_category = product_category;
}
/**
 * @return the product_description
 */
public String getProduct_description() {
	return product_description;
}
/**
 * @param product_description the product_description to set
 */
public void setProduct_description(String product_description) {
	this.product_description = product_description;
}
/**
 * @return the product_price
 */
public double getProduct_price() {
	return product_price;
}
/**
 * @param product_price the product_price to set
 */
public void setProduct_price(double product_price) {
	this.product_price = product_price;
}
}
