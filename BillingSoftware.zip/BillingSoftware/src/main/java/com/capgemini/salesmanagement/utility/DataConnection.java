package com.capgemini.salesmanagement.utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataConnection {

	public Connection connect() throws SQLException, ClassNotFoundException {
		Connection con=null;
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/batch2","root","tharak438");
		return con;
		
		
	}
}
