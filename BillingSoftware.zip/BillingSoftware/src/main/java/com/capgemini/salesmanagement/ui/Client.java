/**
 * 
 */
package com.capgemini.salesmanagement.ui;

/**
 * @author VJIT
 *
 */
public class Client {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
