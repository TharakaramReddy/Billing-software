package com.capgemini.salesmanagement.dao;

import junit.framework.TestCase;

public class ProductDAOTest extends TestCase {

}
